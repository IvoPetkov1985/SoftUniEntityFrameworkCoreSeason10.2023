﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-T8N6Q4C\SQLEXPRESS;Database=CarDealerXml;Integrated Security=True;Encrypt=False";
    }
}
